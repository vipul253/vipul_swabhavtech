angular.module('studentControllers').service('dataService',['$http', function ($http) {
    var url = "http://gsmktg.azurewebsites.net/api/v1/techlabs/test/students/";

    this.getData = function () {
        return $http.get(url);
    }

    this.addData = function (stud) {
        return $http.post(url, stud);
    }

}]);